#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <time.h>
#include <SDL/SDL.h>
#include <SDL/SDL_image.h>
#include <SDL/SDL_mixer.h>
#include "personnage.h"


void initialiser_personnage(personnage *p)
{

char nomFich[3];
int i;
for(i=0;i<3;i++)
{
    sprintf(nomFich,"%d.png",i);
    p->tab[i]=IMG_Load("nomFich");
}
// position perso
p->position.x=0;
p->position.y=380;
//p->sens_mouvement=1;
p->position_actuel=1;  // mariem moch normalement houni fama compteur ++? khater el position tetbadel elle depends fin howoi a chaque fois 

p->time=0;
p->score=100; // mafhemtich el faza hedhi chniya time score et vie fhemtich kifeh normalement ils dependent mel les fonctions score et vie et temps?
p->vie=5;
}

void afficher_personnage(personnage *p,SDL_Surface *ecran)
{
    SDL_BlitSurface(p->tab[p->position_actuel],NULL,ecran,&(p->position));
}

/*---------------------------------- Animation RIGHT ---------------------------------*/

void animation_right (personnage *p)
{int x;
  p->direction=0;
	if(p->Frame<=0 || p->Frame>=15)
		p->Frame=0;
	p->Frame++;
	if (p->Frame>=x)
		p->Frame=0;
}


/*---------------------------------- Animation LEFT ---------------------------------*/
void animation_left (personnage *p)
{int x;
  p->direction=1;
	if(p->Frame<=14 || p->Frame>=30)
		p->Frame=15;

	p->Frame++;
	if (p->Frame>=2*x)
		p->Frame=16;
}

/*---------------------------------- Animation CLAVIER ---------------------------------*/

void animer_clavier(personnage* p)
{
	int sens=0;

    if(sens==2)
    {
        if(p->position_actuel>=11)
        {
            p->position_actuel=0;
        }
        else
        {
            if(p->position_actuel<10)
            {
            	p->position_actuel++;
            }
            else 
            {
                p->position_actuel=0;
            }
        }
    }
    else if(sens==1)
    {
        if(p->position_actuel<11)
        {
            p->position_actuel=21;
        }
        else
        {
            if(p->position_actuel<21)
            {
                p->position_actuel++;
            }
            else
            {
                p->position_actuel=11;
            }
        }
    }
}



