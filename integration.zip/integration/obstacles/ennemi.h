#include <stdio.h>
#include <stdlib.h>
#include <SDL/SDL.h>
#include <SDL/SDL_image.h>
#include <SDL/SDL_mixer.h>
#include <SDL/SDL_ttf.h>

typedef struct ennemi
{

		int position_max_x;
		 int position_min_x;

		 int frameup;
		 int framedown;

		  int frameleft;
		int frameright;
		int position_aleatoire_max_x;
		int position_aleatoire_max_y;
	
		int position_aleatoire_min_x;
		int position_aleatoire_min_y;
		  	
			int position_min_y;
		  	int position_max_y;

		  	SDL_Rect  position_entite ;
			SDL_Rect pos_affichage;

			SDL_Rect position_map;
	
			int curframe;
			int maxframe;
		int choix;
			SDL_Rect frame;
	
} ennemi;

void initialiser_ennemi(ennemi *en[],int n);
void afficher_ennemi(ennemi *en[], SDL_Surface *ecran);
