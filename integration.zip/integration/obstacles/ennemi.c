#include <stdio.h>
#include <stdlib.h>
#include <SDL/SDL.h>
#include <SDL/SDL_image.h>
#include <SDL/SDL_mixer.h>
#include <SDL/SDL_ttf.h>
#include "ennemi.h"

void initialise_ennemi(ennemi en[],int n) 

{
	char entites[20];
	int i;
  for ( i = 0; i < n; i++)
  {
  	en[i]->position_max_x=0;
  	en[i]->position_min_x=0;

  	en[i]->frameup=0;
  	en[i]->framedown=96;

  	en[i]->frameleft=48;
  	en[i]->frameright=144;

	en[i]->position_aleatoire_max_x=0;
	en[i]->position_aleatoire_max_y=0;
	en[i]->position_aleatoire_min_x=0;
	en[i]->position_aleatoire_min_y=0;
  	
	en[i]->position_min_y=0;
  	en[i]->position_max_y=0;

  	en[i]->position_en.x=0 ; 
  	en[i]->position_en.y=0 ; 
	
	en[i]->pos_affichage.x=0;
	en[i]->pos_affichage.y=0;

	en[i]->position_map.x=0;
	en[i]->position_map.y=0;
	en[i]->curframe=0;
	en[i]->maxframe=2;
	en[i]->choix=i;
	en[i]->frame.y=0;
	en[i]->frame.x=0;
	en[i]->frame.h=48;
	en[i]->frame.w=48;
	
if (i==2)
	{
	en[i].frameup=0;
  	en[i].framedown=0;
  	en[i].frameleft=0;
  	en[i].frameright=0;
	en[i].maxframe=6;
	en[i].frame.h=60;
	en[i].frame.w=60;	
	}

	if (i==3)
	{
en[i].frame.x=48;
	en[i].frame.h=48;
	en[i].frame.w=48;
en[i].frame.y=96;

	}
		if (i==4)
	{
en[i].frame.x=48;
	en[i].frame.h=48;
	en[i].frame.w=48;
en[i].frame.y=0;

	}
		if (i==5)
	{
en[i].frame.x=0;
	en[i].frame.h=134;
	en[i].frame.w=150;
en[i].frame.y=0;

	}
if (i==6)

{
en[i].maxframe=59;


}
if (i==7)

{
en[i].maxframe=59;


}
if (i==8)

{
en[i].maxframe=59;


}

if (i==10)

{

en[i].maxframe=59;

}

en[i].affichage_ou_non=0;
	sprintf(entites,"ennemi/ennemi/%d.png",i);

  	en[i].affichage_secondaire=IMG_Load(entites); 
}
}

void afficher_ennemi (ennemi *en[], SDL_Surface *ecran) 
{
	
	SDL_BlitSurface(en->affichage_secondaire,&en->frame,ecran,&en->position_map);
	

}
