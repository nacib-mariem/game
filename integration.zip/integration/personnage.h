#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <time.h>
#include <SDL/SDL.h>
#include <SDL/SDL_image.h>
#include <SDL/SDL_mixer.h>


typedef struct personnage
{
	int vie;
	int direction;
	int nb_frames_p;
	int Frame;
	int sens_mouvement;
	int position_actuel; 
	//int positiongauche;
    SDL_Rect position;
	SDL_Surface *tab[10];
	float time;
	int score;
	SDL_Rect pos_score;
    int stage; 
	int objective; 
}personnage;


void initialiser_personnage(personnage *p);
void afficher_personnage(personnage *p,SDL_Surface *ecran);
void animation_right (personnage *p);
void animation_left (personnage *p);
void animer_clavier(personnage * p);
