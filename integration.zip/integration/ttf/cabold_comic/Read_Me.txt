Thanks for downloading our font.
This is demo version.
if you would like to consider using it for commercial projects, please visit this page and buy it with full family set.
http://www.studiotypo.com/shop/index.php?rt=product/product&product_id=24

if you want test the full character set, visit this page.
http://www.studiotypo.com/shop/index.php?rt=product/product&product_id=24

Thanks


