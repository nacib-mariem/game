#include<stdio.h>
#include<stdlib.h>
#include"SDL/SDL.h"
#include"SDL/SDL_image.h"
#include"SDL/SDL_ttf.h"
#include"SDL/SDL_mixer.h"
#include"collision.h"
#include"jeu.h"
#include"back.h"
#include"obstacle.h"
#include"pp.h"
#include"vie.h"



void jeu()
{


int continuer=1;
//initiation
SDL_Init(SDL_INIT_VIDEO);
if (SDL_Init(SDL_INIT_VIDEO))
fprintf(stderr,"Error SDL : %s\n",SDL_GetError());


//creation fenetre
SDL_Surface *fenetre=NULL;
fenetre=SDL_SetVideoMode(807,720,32,SDL_HWSURFACE);

SDL_FillRect(fenetre,NULL,SDL_MapRGB(fenetre->format,0,0,0));
SDL_Flip(fenetre);

Background B;
charger_Background(&B);



SDL_Rect camera_pos;
initBackground(&B,&camera_pos);
SDL_BlitSurface(B.backgroundImg,NULL,fenetre,&B.back_Pos);
SDL_Flip(fenetre);



//initialisation obstacle et affichage 
obstacle ob;
obstacle ob1;
obstacle ob2;



initialiser_obstacle(&ob);
initialiser_obstacle1(&ob1);
initialiser_obstacle2(&ob2);

afficher_obstacle(fenetre,ob);
SDL_Flip(fenetre);



hero h;
charger(&h);
initialiser(&h);



//SDL_BlitSurface(h.image,NULL,fenetre,&B.back_Pos);

vie v;
initialiservie(&v);


//boucle du jeu

while(continuer)
{
SDL_Event event;
SDL_WaitEvent(&event);

if(event.type==SDL_QUIT)
{
continuer=0;
break;
}





else if(event.type==SDL_KEYDOWN){
  if(event.key.keysym.sym==SDLK_RIGHT){
if((h.rcSprite.x>=400)&&(camera_pos.x<473))
{

camera_pos.x+=50;
ob.obstacle_pos.x-=10;
ob1.obstacle_pos.x-=10;
ob2.obstacle_pos.x-=10;

}
else 
{

             h.rcSprite.x+=50;

}


 if ( h.rcSrc.x ==202)
            h.rcSrc.x =303;
          else
            h.rcSrc.x=202;


if((collision(h.rcSprite,ob.obstacle_pos)==1)||(collision(h.rcSprite,ob1.obstacle_pos)==1)||(collision(h.rcSprite,ob2.obstacle_pos)==1))
{
v.nb--;
h.rcSprite.x-=300;




}


if(v.nb==0)
{
continuer=0;
}




}

  else if(event.key.keysym.sym==SDLK_LEFT){
if(camera_pos.x>0)
{

camera_pos.x-=50;

ob.obstacle_pos.x+=10;
ob1.obstacle_pos.x+=10;
ob2.obstacle_pos.x+=10;
}

else
{
          h.rcSprite.x -=50;
}



if (h.rcSrc.x==0)
            h.rcSrc.x=95.72;
          else
            h.rcSrc.x =0;


if((collision(h.rcSprite,ob.obstacle_pos)==1)||(collision(h.rcSprite,ob1.obstacle_pos)==1)||(collision(h.rcSprite,ob2.obstacle_pos)==1))
{
v.nb--;
h.rcSprite.x+=150;


}

if(v.nb==0)
{
continuer=0;
}



}
 if ( h.rcSprite.x < 0 ) {
      h.rcSprite.x = 0;
    }
    else if ( h.rcSprite.x > 807-95.72) {
      h.rcSprite.x =  807-95.72;
    }
 


}

else if(event.key.keysym.sym==SDLK_UP)
{


h.rcSprite.y-=30;






}
else if(event.key.keysym.sym==SDLK_DOWN)
{
h.rcSprite.y+=30;

}









affichervie(v,fenetre);
afficher(fenetre,&h);
blitBackground(B,fenetre,camera_pos);
afficher_obstacle(fenetre,ob);
afficher_obstacle(fenetre,ob1);
afficher_obstacle(fenetre,ob2);










}


SDL_FreeSurface(fenetre);
freeBackground(&B);
//liberervie(&v);
liberer_obstacle(&ob);
//liberer_obstacle(&ob1);
//liberer_obstacle(&ob2);
liberer_hero(&h);
SDL_Quit();


}

void play_animation(SDL_Surface *GIF_Img[], int i, int delay, SDL_Surface *Screen) {

if(Mix_OpenAudio(44100, MIX_DEFAULT_FORMAT,MIX_DEFAULT_CHANNELS, 1024) == -1) //Initialisation de l'API Mixer
   {
      printf("%s", Mix_GetError());
   }
Mix_Music *musique1; //Création du pointeur de type Mix_Music
musique1 = Mix_LoadMUS("spray.mp3"); //Chargement de la musique
//repetition de la musique
Mix_PlayMusic(musique1,1);

	for (int k = 1 ; k <= i; k++) {
             
		SDL_Flip(Screen);
		SDL_BlitSurface(GIF_Img[k], NULL, Screen, NULL);
		SDL_Flip(Screen);
		SDL_Delay(delay);
	}
Mix_FreeMusic(musique1);
Mix_CloseAudio();
}

void play_animation1(SDL_Surface *GIF_Img[], int i, int delay, SDL_Surface *Screen) 
{
for (int k = 17 ; k <=19; k++) {
             
		SDL_Flip(Screen);
		SDL_BlitSurface(GIF_Img[k], NULL, Screen, NULL);
		SDL_Flip(Screen);
		SDL_Delay(delay);
	}

}
Fin de la discussion
Écrivez un message, @nom...


